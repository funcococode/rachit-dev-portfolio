# Rachit Shrivastava — Portfolio

React 19 · Vite · Tailwind CSS v4 · Framer Motion · Lenis smooth scroll · React Router

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build → dist/
npm run preview
```

Deploys as-is to Vercel (`vercel.json`) or Netlify (`public/_redirects`) — both rewrite routes to `index.html` so `/work/:slug` pages work on refresh.

## Edit your content

| What | Where |
| --- | --- |
| Name, email, socials, timezone, availability, stack, capabilities, process | `src/data/site.js` |
| Projects & case studies | `src/data/projects.js` |
| Colours, fonts, easing | `@theme` block in `src/index.css` |

**Please check each project's `role`, `year` and `stack`** — they're best guesses.

### Adding real screenshots
Each project draws its own animated generative cover until you add images:

1. Put files in `public/projects/<slug>/`, e.g. `public/projects/trip-unplanned/cover.jpg`
2. In `projects.js`: `images: ['/projects/trip-unplanned/cover.jpg', '/projects/trip-unplanned/desktop.jpg', '/projects/trip-unplanned/mobile.jpg']`
   - `[0]` → cover (hover preview + case-study hero) · `[1]` → browser mockup · `[2]` → phone mockup (use a tall mobile screenshot)

## Structure

```
src/
  components/   reusable building blocks
    SplitText         masked char/word reveal
    ScrollRevealText  words light up with scroll (*word* = accent italic)
    Magnetic          pulls children toward the cursor
    RollText          letter-roll hover for links
    Marquee           infinite, scroll-velocity-reactive marquee
    Waveform          living audio waveform (cursor + audio reactive)
    Vinyl             spinning record
    Cursor            custom cursor — add data-cursor="Label" to any element
    Preloader         counter + word cycle + curtain
    PageTransition    route curtains
    ProjectArt        generative project covers / screenshots
    BrowserFrame, CountUp, LocalTime, SectionLabel, Nav, Footer
  hooks/        useSynth (Web Audio ambient loop), useMediaQuery, useLoader, useGoToSection
  sections/     Hero, About, Work, Process, Stack, Music
  pages/        Home, CaseStudy (/work/:slug), NotFound
  data/         site.js, projects.js
```

Animations respect `prefers-reduced-motion`. The custom cursor only appears on devices with a fine pointer.
